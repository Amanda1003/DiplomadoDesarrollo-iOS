//: [Previous](@previous)

import Foundation

var counter = 1
while counter < 10
{
    print(counter)
    counter += 1
}
//: [Next](@next)

counter = 1
repeat
{
    print(counter)
    counter += 1
}
while counter < 10


// EJERCIICO: SERPIENTES Y ESCALERAS
let dado = Int.random(in: 1...6)
let posicion = 0
tablero = posicion + dado
while posicion <=24
{
    switch tablero {
    case tablero == 24:
        print("¡Ganaste")
        break
    case tablero == 2:
        posicion = 10
        print("2",posicion)
    case tablero == 13:
        posicion = 3
        print("3",posicion)
    case tablero == 9:
        posicion = 11
        print("9",posicion)
    case tablero == 8:
        posicion = 17
        print("8",posicion)
    case tablero == 5:
        posicion = 16
        print("5",posicion)
    case tablero == 23:
        posicion = 15
        print("23",posicion)
    case tablero == 21:
        posicion = 19
        print("21",posicion)
    case tablero == 18:
        posicion = 7
        print("18",posicion)
    default:
        posicion += dado
        print("default",posicion)
    }
}
tablero = posicion + dado
