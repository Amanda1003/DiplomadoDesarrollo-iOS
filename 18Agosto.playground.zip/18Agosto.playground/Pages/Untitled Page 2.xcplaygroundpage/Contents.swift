//: [Previous](@previous)

import Foundation

var cellphone: String = "55983428"
var landline: String?! = nil

print(cellphone)
/*!print (landline ?? "no tengo teléfono de línea") // Es equivalente a ? coso:cosa
print(landline!)
if let landline2 = landline
{
    print(landline2)
}
*/
guard let landline2 = landline
        else
{
    fatalError("oops")
}
print(landline2)
