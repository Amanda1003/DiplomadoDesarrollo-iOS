//: (Previous](@previous)
import Foundation

let animal = "dog"
switch animal
{
//case "dog":print("🐶")
//case "cat":
//    print("🐯")
//    print("🐱")
case "mouse": print("🐭")
case "bird" : print("🦆")
case "dog", "cat":  //Caso compuesto, denotado por la coma.
    print("Amo a los perros y los gatos están bien.")
//default : break
default : print("Están bien.")
}



let grade = 9
switch grade
{
case ...5: print("Failed")
case 6..<8: print("Mehh")
case 8...9: print("¡Excelente!")
case 10: print("Woooow")
default: print(":v Sospechoso...")
}


let color = (255, 255, 255)
switch color   //La primera validadción que entra es la que se queda.
{
case (_, _, 255): //guiones bajos = comodines
    print("max blue")
    fallthrough   //Sigue pero no valida, como que lleva a cabo las instrucciones, sin validar que se cumnplan las condiciones.
case (_, 255, _): print("max green")
case (255, _, _): print("max red")
default: break
}



//Value binding

switch color
{
case (let r, let g, 255): // las variables r, b, son locales del case.
    print("red: \(r), green: \(g), max blue")
case let (r, 255, b): print("red: \(r), max green, blue: \(b)")
case let (255, g, b) where g < 255:
    print("max red with green \(g), and blue: \(b)")
default: break
}

//static var pi: Self {get}
let coordenada = (1.4,-3.5)
switch coordenada
{
case (_, 0): print("Está en el eje X y las coordenadas son \(coordenada)")
case (0, _): print("Está en el eje Y y las coordenadas son \(coordenada)")
case (0.1...5, 0...5): print("Está en el primer cuadrante y las coordenadas son \(coordenada)")
case (-5..<0, 0.1...5): print("Está en el segundo cuadrante y las coordenadas son \(coordenada)")
case (0.1...5, -5..<0): print("Está en el cuarto cuadrante y las coordenadas son \(coordenada)")
case (-5..<0,-5..<0): print("Está en el tercer cuadrante y las coordenadas son \(coordenada)")
case (0,0): print("Estás en el origen")
default: print("Está fuera de rango")
}


guard animal == "dog"
        else
{
    fatalError("It's not a dog")
}
