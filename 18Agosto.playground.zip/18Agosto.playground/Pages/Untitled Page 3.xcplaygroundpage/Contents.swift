//: [Previous](@previous)

import Foundation

// Numeradores
// Se nombran en uppercamencase y en singular
//: [Next](@next)

enum Pet: String
{
    case dog = "🦟"
    // case cat = "🦟"  no sabe qué chuchas porque hay dos case a los cuales se asocia el mismo emoji,
    case cat = "🐸"
    case turtle = "🐢"
    case parakeet = "🦅"
}

//let myPet = Pet(rawValue: "🐰")  //No encontró nada, entonces es nulo el valor que regresa.
let myPet = Pet(rawValue: "🦟")
let myTurtle: Pet = .turtle
let myParakeet = Pet.parakeet

switch myPet   //infiere que todos los casos son de tipo Pet
{
    //case .dog: print("🐶")
default: print(myPet!.rawValue)
//default: print(myPet?.rawValue ??)
    Pet.turtle.rawValue
    //default: break
}

//! Existe, ? Puede que no exista.



let intervals = stride(from: 0, to: 20, by: 5)
let intervals2 = stride(from: -5, to: 20, by: 10)
let intervals3 = stride(from: 0, to: 20, by: 15)
for i in intervals
{
    print(i)
}
for i in intervals2
{
    print(i)
}
for i in intervals3
{
    print(i)
}

let pokemon = ["Fire": "Charmander", "Water": "Mudpik", "Grass": "Turtwing", "Electric": "Pikachu"]
for (type, name) in pokemon
{
    print("I like \(name) of type \(type)")
}

print("\n\n\n")
for poke in pokemon
{
    print("I like \(poke.value) of type \(poke.key)")
}
//No hay orden en los diccionarios.



// Ejercicio
/*let names: Set = ["James", "Dean", "Sam", "Steve", "Chris"]
print("For-in loop with counter as index")
var index = 0
for _ in names
{
    print(index)
    index+=1
}
*/

let names: Array = ["James", "Dean", "Sam", "Steve", "Chris"]
print("\n\nFor-in loop enumerated")
for (index2, name) in names.enumerated()
{
    print(index2,name)
}

for(index, pokemon) in pokemon.enumerated()
{
    print("\(index), \(pokemon)")
}

for(index, (type, name)) in pokemon.enumerated()
{
    print("\(index), \(type) \(name)")
}


for(index, name) in names.enumerated()
{
    if index%2 == 0
    {
        print(name)
    }
    else
    {
        break
    }
}

for(index, name) in names.enumerated()
{
    if index%2 == 0
    {
        continue
    }
    print(index, name)
}

for(index, name) in names.enumerated()
    where index % 2 == 0
    {
        print(name)
    }

for poke in pokemon where poke.key == "Fire"
{
    print(poke.value)
}
