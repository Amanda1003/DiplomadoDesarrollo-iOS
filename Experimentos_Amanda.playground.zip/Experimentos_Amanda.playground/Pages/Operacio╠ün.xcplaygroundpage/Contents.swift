//: [Previous](@previous)

import Foundation

let operacion: Float = 6+((4*(8-1))/2)
print(operacion)
