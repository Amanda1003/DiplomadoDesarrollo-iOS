//: [Previous](@previous)

import Foundation

var valor: Int = 0
let incremento: Int = 15

while valor <= 60
{
    print(valor)
    valor = valor + incremento
}
