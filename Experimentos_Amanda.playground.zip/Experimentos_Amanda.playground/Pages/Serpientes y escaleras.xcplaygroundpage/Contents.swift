//: [Previous](@previous)

import Foundation

var posicion: Int = 0
while posicion <= 24
{
    var dado = Int.random(in: 1...6)
//    print(dado)
    var oldPosition = posicion
    var newposition = posicion + dado
    if newposition == 2
    {
        posicion = 10
    }
    else if newposition == 13
    {
        posicion = 3
    }
    else if newposition == 5
    {
        posicion = 16
    }
    else if newposition == 8
    {
        posicion = 17
    }
    else if newposition == 9
    {
        posicion = 11
    }
    else if newposition == 23
    {
        posicion = 15
    }
    else if newposition == 18
    {
        posicion = 7
    }
    else if newposition == 21
    {
        posicion = 19
    }
    else
    {
            posicion = posicion + dado
    }
    print("Tu posición era \(oldPosition), el valor del dado fue \(dado) y tu posición actual es \(posicion)")
}
//print (posicion)
print ("¡Llegaste a la casilla final!")
