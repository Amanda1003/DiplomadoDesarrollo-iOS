//: [Previous](@previous)

import Foundation

var xycoord: (Float, Float) = (0.1, 0.2)
//let ycoord: Float = 1.0

switch (xycoord) {
    case let (x,y) where x == 0.0 && y == 0.0:
        print("Es el origen y las coordenadas son \(xycoord)")
    case let (x,_) where x == 0.0:
        print("Estás sobre el eje X y las coordenadas son \(xycoord)")
    case let (_,y) where y == 0.0:
        print("Estás sobre el eje Y y las coordenadas son \(xycoord)")
    case let (x,y) where 0...5 ~= x && 0...5 ~= y:
        print("Estás en el primer cuadrante y las coordenadas son \(xycoord)")
    case let (x,y) where -5..<0 ~= x && 0...5 ~= y:
    print("Estás en el segundo cuadrante y las coordenadas son \(xycoord)")
    case let (x,y) where -5..<0 ~= x && -5..<0 ~= y:
    print("Estás en el tercer cuadrante y las coordenadas son \(xycoord)")
    case let (x,y) where 0...5 ~= x && -5..<0 ~= y:
    print("Estás en el cuarto cuadrante y las coordenadas son \(xycoord)")
    default:
        print("No estás dentro de las coordenadas permitidas.")
}
