//: [Previous](@previous)

import Foundation

var werather: String = "Nieve"
var time: Int = 23

//La parte del clima
if werather == "Lluvia"
{
    print("🌧️")
}
else if werather == "Nieve"
{
    print("🌨️")
}

var nobloqueador: [Int] = Array(0...6) + Array(19...23)
var bloqueador: [Int] = Array(7...18)

if bloqueador.contains(time)
{
    print("Usa bloqueador")
}
else if nobloqueador.contains(time)
{
    print("No es necesario que uses bloqueador")
}

